Place the following piano note audio files in this directory:
- C.mp3
- D.mp3
- E.mp3
- F.mp3
- G.mp3
- A.mp3
- B.mp3

You can find free piano note samples online or record your own.