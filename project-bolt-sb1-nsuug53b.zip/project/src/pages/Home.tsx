import React from 'react';
import PianoKeys from '../components/PianoKeys';

function Home() {
  return (
    <main className="container mx-auto px-4">
      <div className="h-screen flex flex-col items-center justify-center">
        <h1 className="text-6xl font-serif mb-8 text-center">AIYANA</h1>
        <div className="w-full max-w-5xl">
          <PianoKeys />
        </div>
      </div>
    </main>
  );
}

export default Home;