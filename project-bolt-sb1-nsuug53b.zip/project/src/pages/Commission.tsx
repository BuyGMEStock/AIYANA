import React, { useRef } from 'react';
import { useInView } from 'react-intersection-observer';
import ContactForm from '../components/ContactForm';

const services = [
  {
    title: "Anthems",
    description: "Custom compositions for organizations, events, and special occasions. Each anthem is crafted to embody your values and vision.",
    image: "https://images.unsplash.com/photo-1520523839897-bd0b52f945a0?auto=format&fit=crop&q=80&w=2000"
  },
  {
    title: "Restaurant Ambiance",
    description: "Elevate your dining experience with sophisticated piano performances. Creating the perfect atmosphere for your establishment.",
    image: "https://images.unsplash.com/photo-1466978913421-dad2ebd01d17?auto=format&fit=crop&q=80&w=2000"
  },
  {
    title: "Private Events",
    description: "Bespoke musical experiences for weddings, corporate gatherings, and exclusive celebrations.",
    image: "https://images.unsplash.com/photo-1530968464165-7a1861cbaf9f?auto=format&fit=crop&q=80&w=2000"
  },
  {
    title: "Studio Sessions",
    description: "Professional piano recordings for your projects, featuring state-of-the-art equipment and expertise.",
    image: "https://images.unsplash.com/photo-1598488035139-bdaa7543d5d4?auto=format&fit=crop&q=80&w=2000"
  }
];

function Commission() {
  const { ref: topRef, inView: topVisible } = useInView({ threshold: 0.5 });

  return (
    <div className="w-full">
      {services.map((service, index) => (
        <section
          key={index}
          className="relative h-screen w-full overflow-hidden"
          ref={index === 0 ? topRef : undefined}
        >
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{ 
              backgroundImage: `url(${service.image})`,
              transform: topVisible && index === 0 ? 'scale(1.1)' : 'scale(1)',
              transition: 'transform 0.8s ease-out'
            }}
          >
            <div className="absolute inset-0 bg-black bg-opacity-50" />
          </div>
          
          <div className="relative h-full flex flex-col items-center justify-center text-white p-8">
            <h2 className="text-6xl font-serif mb-6 text-center">{service.title}</h2>
            <p className="text-xl max-w-2xl text-center font-serif">{service.description}</p>
          </div>
        </section>
      ))}

      <section className="min-h-screen bg-black relative px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-serif mb-12 text-center">Get in Touch</h2>
          <ContactForm />
        </div>
      </section>
    </div>
  );
}

export default Commission;