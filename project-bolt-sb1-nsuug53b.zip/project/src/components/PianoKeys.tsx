import React, { useState, useEffect } from 'react';

const notes = [
  { note: 'C', text: 'Classical virtuoso performing worldwide' },
  { note: 'D', text: 'Dedicated to the art of piano' },
  { note: 'E', text: 'Enchanting performances that move souls' },
  { note: 'F', text: 'Fusion of tradition and innovation' },
  { note: 'G', text: 'Graceful interpretations of timeless pieces' },
  { note: 'A', text: 'Artistic excellence in every note' },
  { note: 'B', text: 'Bringing music to life' },
];

const PianoKeys = () => {
  const [activeKey, setActiveKey] = useState<number | null>(null);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [hasInteracted, setHasInteracted] = useState(false);

  useEffect(() => {
    // Create AudioContext on component mount
    const context = new (window.AudioContext || (window as any).webkitAudioContext)();
    setAudioContext(context);

    // Cleanup on unmount
    return () => {
      if (context) {
        context.close();
      }
    };
  }, []);

  const playNote = async (frequency: number) => {
    if (!audioContext || !hasInteracted) return;

    try {
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      // Use sine wave for a softer piano-like sound
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
      
      // Apply envelope
      gainNode.gain.setValueAtTime(0, audioContext.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.5, audioContext.currentTime + 0.1);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 1);
      
      oscillator.start();
      oscillator.stop(audioContext.currentTime + 1);
    } catch (error) {
      console.error('Error playing note:', error);
    }
  };

  // Map notes to frequencies (in Hz)
  const getNoteFrequency = (note: string): number => {
    const frequencies: { [key: string]: number } = {
      'C': 261.63, // Middle C
      'D': 293.66,
      'E': 329.63,
      'F': 349.23,
      'G': 392.00,
      'A': 440.00,
      'B': 493.88,
    };
    return frequencies[note] || 440;
  };

  const handleInteraction = () => {
    if (!hasInteracted && audioContext) {
      setHasInteracted(true);
      // Resume AudioContext on first interaction
      audioContext.resume();
    }
  };

  return (
    <div className="relative" onClick={handleInteraction}>
      <div className="flex">
        {notes.map((note, index) => (
          <div
            key={index}
            className="relative flex-1"
            onMouseEnter={() => {
              setActiveKey(index);
              playNote(getNoteFrequency(note.note));
            }}
            onMouseLeave={() => setActiveKey(null)}
          >
            <div className={`
              h-[calc(100vh-200px)] 
              border-l border-gray-800
              transition-colors duration-300
              ${activeKey === index ? 'bg-gray-800' : 'bg-white'}
              ${index === notes.length - 1 ? 'border-r' : ''}
              cursor-pointer
            `}>
              {activeKey === index && (
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-center w-full px-4">
                  <p className={`text-lg font-serif ${activeKey === index ? 'text-white' : 'text-black'}`}>
                    {note.text}
                  </p>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PianoKeys;